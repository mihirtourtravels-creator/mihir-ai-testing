// MIHIR AI Testing Mode: no paid provider credentials required.
(function(){
  const realFetch = window.fetch.bind(window);
  const json = (data, ok=true, status=200) => Promise.resolve(new Response(JSON.stringify(data), {status, headers:{'Content-Type':'application/json'}}));
  let credits = Number(localStorage.getItem('mihir_demo_credits') || 1);
  let user = JSON.parse(localStorage.getItem('mihir_demo_user') || 'null');
  const plans = {
    free_trial:{name:'Free Trial',duration_days:1,price:0,credits:1,trial:true}, quick_pass:{name:'1 Day Quick Pass',duration_days:1,price:100,credits:2}, weekly:{name:'Weekly',duration_days:7,price:500,credits:10}, fortnight:{name:'Fortnight',duration_days:15,price:1000,credits:20}, monthly:{name:'Monthly',duration_days:30,price:1500,credits:50}, quarterly:{name:'Quarterly',duration_days:90,price:4000,credits:150}, half_yearly:{name:'Half-Yearly',duration_days:180,price:7000,credits:300}, yearly:{name:'Yearly',duration_days:365,price:11000,credits:1000}
  };
  function mock(url, opts){
    const u = new URL(url, location.href), p=u.pathname, method=(opts&&opts.method||'GET').toUpperCase();
    if(!p.startsWith('/api/')) return realFetch(url,opts);
    if(p==='/api/auth/me') return json({authenticated:!!user,user:user});
    if(p==='/api/auth/signup' && method==='POST'){const b=JSON.parse(opts.body||'{}'); user={email:b.email||'demo@mihir.ai',id:'demo-user'};localStorage.setItem('mihir_demo_user',JSON.stringify(user));return json({user});}
    if(p==='/api/auth/login' && method==='POST'){const b=JSON.parse(opts.body||'{}');user={email:b.email||'demo@mihir.ai',id:'demo-user'};localStorage.setItem('mihir_demo_user',JSON.stringify(user));return json({user});}
    if(p==='/api/auth/logout'){user=null;localStorage.removeItem('mihir_demo_user');return json({ok:true});}
    if(p==='/api/state') return user?json({credits,plan:'free_trial',subscription_expires_at:null,creations:[],projects:[],profiles:[],renders:[]}):json({error:'Authentication required'},false,401);
    if(p==='/api/plans') return json(plans);
    if(p==='/api/subscribe' && method==='POST'){const b=JSON.parse(opts.body||'{}'), plan=plans[b.plan]; if(!plan)return json({error:'Unknown plan'},false,400); if(plan.price>0){return json({error:'Testing Mode: live payment disabled. Use Free Trial for UI testing.'},false,402);} credits=plan.credits;localStorage.setItem('mihir_demo_credits',credits);return json({plan:plan.name,credits});}
    if(p==='/api/generate-storyboard') return json({storyboard:{title:'Demo Promotional Video',script:'यह MIHIR AI testing mode का demo script है।',scenes:[{scene:1,visual_prompt:'Professional business exterior',narration:'आपके व्यवसाय के लिए शानदार प्रचार वीडियो।',on_screen_text:'MIHIR AI Demo'},{scene:2,visual_prompt:'Happy customers',narration:'अपने ब्रांड को बेहतर तरीके से प्रस्तुत करें।',on_screen_text:'Create • Promote • Grow'},{scene:3,visual_prompt:'Brand call to action',narration:'आज ही MIHIR AI के साथ बनाएं।',on_screen_text:'MIHIR AI'}]}});
    if(p==='/api/generate-image') {if(credits<1)return json({error:'No credits'},false,402); credits--;localStorage.setItem('mihir_demo_credits',credits);return json({credits,output_url:'data:text/plain,MIHIR-AI-DEMO-IMAGE'});}
    if(p==='/api/generate-voice') {if(credits<1)return json({error:'No credits'},false,402); credits--;localStorage.setItem('mihir_demo_credits',credits);return json({credits,audio_url:null,disclosure:'AI-generated voice — DEMO MODE'});}
    if(p==='/api/render-video') {if(credits<1)return json({error:'No credits'},false,402); credits--;localStorage.setItem('mihir_demo_credits',credits);return json({credits,render:{output_url:'',audio_attached:false}});}
    if(p==='/api/safety/check') return json({allowed:true,flagged:false,action:'allow'});
    if(p==='/api/avatar/profile') return json({ok:true,profile:{id:'demo-avatar',name:'Demo Authorized Avatar',status:'demo_pending_verification'}});
    if(p==='/api/voice/clone') return json({ok:true,profile:{id:'demo-voice',name:'Demo Authorized Voice',status:'demo_pending_verification'}});
    if(p==='/api/admin/summary') return json({error:'Admin disabled in testing mode'},false,403);
    return json({ok:true,demo:true});
  }
  window.fetch = mock;
})();
