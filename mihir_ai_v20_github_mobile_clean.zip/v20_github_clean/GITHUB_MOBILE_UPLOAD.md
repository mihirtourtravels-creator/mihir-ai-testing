# MIHIR AI v0.20 — GitHub Mobile APK Build

IMPORTANT: GitHub must contain `.github/workflows/android-apk.yml`.
If the mobile file picker hides `.github`, create the workflow from GitHub:
Actions -> New workflow -> set up a workflow yourself, then use the file content from `.github/workflows/android-apk.yml`.

Android project is under `android/`.
